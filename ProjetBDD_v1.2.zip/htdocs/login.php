<?php
session_start();
require 'config/db.php';

/* Récupération des données du formulaire */
$username = $_POST['username'];
$password = $_POST['password'];

/* Recherche de l'utilisateur */
$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch();

/* Vérification du mot de passe */
if ($user && password_verify($password, $user['password'])) {

    /* Stockage en session */
    $_SESSION['user'] = $user['username'];
    $_SESSION['role'] = $user['role']; // 👈 ADMIN ou USER

    /* Redirection */
    header("Location: dashboard.php");
    exit;

} else {
    header("Location: index.php?error=1");
    exit;
}
