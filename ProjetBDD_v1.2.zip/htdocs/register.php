<?php
require 'config/db.php';

$username = $_POST['username'];
$password = $_POST['password'];

/* Vérifier si le username existe déjà */
$stmt = $pdo->prepare(
    "SELECT id FROM users WHERE username = ?"
);
$stmt->execute([$username]);

if ($stmt->fetch()) {
    header("Location: visitor.php?error=1");
    exit;
}

/* Hash du mot de passe */
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

/* Insertion utilisateur (role = user) */
$stmt = $pdo->prepare(
    "INSERT INTO users (username, password, role) VALUES (?, ?, 'user')"
);

$stmt->execute([
    $username,
    $hashedPassword
]);

header("Location: visitor.php?success=1");
exit;
