<?php
require 'config/db.php';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>CitaTime — Visiteur</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<header>📖 Citations publiques</header>

<main class="main-content">

<h2>Citations</h2>

<?php
$stmt = $pdo->query(
    "SELECT content, citation_author
     FROM citations
     ORDER BY created_at DESC"
);

foreach ($stmt as $row):
?>

<div class="citation-card">
    <p>
        “<?php echo htmlspecialchars($row['content']); ?>”<br>
        <em>— <?php echo htmlspecialchars($row['citation_author']); ?></em>
    </p>
</div>

<?php endforeach; ?>

<hr>

<h2>Inscription</h2>

<form action="register.php" method="POST">
    <input type="text" name="username"
           placeholder="Nom d'utilisateur" required><br><br>

    <input type="password" name="password"
           placeholder="Mot de passe" required><br><br>

    <button type="submit" class="btn btn-edit">Créer un compte</button>
</form>

<?php if (isset($_GET['error'])): ?>
<p style="color:red;">Nom d'utilisateur déjà utilisé</p>
<?php endif; ?>

<?php if (isset($_GET['success'])): ?>
<p style="color:green;">Compte créé avec succès</p>
<?php endif; ?>

<br>
<a href="index.php">⬅ Retour</a>

</main>
</body>
</html>
