<?php
echo password_hash("gabriel", PASSWORD_DEFAULT);
