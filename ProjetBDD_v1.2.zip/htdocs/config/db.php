<?php

try {
    $pdo = new PDO(
        "mysql:host=sql100.infinityfree.com;dbname=if0_40959602_tpbdd;charset=utf8",
        "if0_40959602",
        "sTDHwV2Rti7R6Zz",
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
