<?php
session_start();
require 'config/db.php';

/* =========================
   SÉCURITÉ
========================= */
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

/* =========================
   AJOUT
========================= */
if (!empty($_POST['citation']) && !empty($_POST['citation_author'])) {

    $stmt = $pdo->prepare(
        "INSERT INTO citations (content, citation_author, author)
         VALUES (?, ?, ?)"
    );
    $stmt->execute([
        $_POST['citation'],
        $_POST['citation_author'],
        $_SESSION['user']
    ]);

    header("Location: dashboard.php");
    exit;
}

/* =========================
   SUPPRESSION
========================= */
if (!empty($_POST['delete_id'])) {

    if ($_SESSION['role'] === 'admin') {
        $stmt = $pdo->prepare("DELETE FROM citations WHERE id = ?");
        $stmt->execute([$_POST['delete_id']]);
    } else {
        $stmt = $pdo->prepare(
            "DELETE FROM citations WHERE id = ? AND author = ?"
        );
        $stmt->execute([
            $_POST['delete_id'],
            $_SESSION['user']
        ]);
    }

    header("Location: dashboard.php");
    exit;
}

/* =========================
   MODIFICATION
========================= */
if (
    !empty($_POST['update_id']) &&
    !empty($_POST['new_content']) &&
    !empty($_POST['new_citation_author'])
) {

    if ($_SESSION['role'] === 'admin') {
        $stmt = $pdo->prepare(
            "UPDATE citations
             SET content = ?, citation_author = ?
             WHERE id = ?"
        );
        $stmt->execute([
            $_POST['new_content'],
            $_POST['new_citation_author'],
            $_POST['update_id']
        ]);
    } else {
        $stmt = $pdo->prepare(
            "UPDATE citations
             SET content = ?, citation_author = ?
             WHERE id = ? AND author = ?"
        );
        $stmt->execute([
            $_POST['new_content'],
            $_POST['new_citation_author'],
            $_POST['update_id'],
            $_SESSION['user']
        ]);
    }

    // ✅ REDIRECTION = disparition du formulaire
    header("Location: dashboard.php");
    exit;
}

/* =========================
   RÉCUPÉRATION POUR MODIF
========================= */
$citationToEdit = null;

if (!empty($_GET['edit_id'])) {

    if ($_SESSION['role'] === 'admin') {
        $stmt = $pdo->prepare(
            "SELECT id, content, citation_author
             FROM citations
             WHERE id = ?"
        );
        $stmt->execute([$_GET['edit_id']]);
    } else {
        $stmt = $pdo->prepare(
            "SELECT id, content, citation_author
             FROM citations
             WHERE id = ? AND author = ?"
        );
        $stmt->execute([
            $_GET['edit_id'],
            $_SESSION['user']
        ]);
    }

    $citationToEdit = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>CitaTime — Dashboard</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    Bienvenue <?php echo htmlspecialchars($_SESSION['user']); ?>
    <?php if ($_SESSION['role'] === 'admin'): ?>
        👑 <strong>ADMIN</strong>
    <?php endif; ?>
</header>

<main class="main-content">

<!-- =========================
     AJOUT
========================= -->
<h2>Ajouter une citation</h2>

<form method="POST">
    <input type="text"
           name="citation_author"
           placeholder="Auteur de la citation"
           required>
    <br><br>

    <textarea name="citation"
              rows="4"
              placeholder="Texte de la citation"
              required></textarea>
    <br><br>

    <button type="submit" class="btn btn-edit">➕ Ajouter</button>
</form>

<hr>

<!-- =========================
     MODIFICATION
========================= -->
<?php if ($citationToEdit): ?>
<h2>Modifier la citation</h2>

<form method="POST">
    <input type="text"
           name="new_citation_author"
           value="<?php echo htmlspecialchars($citationToEdit['citation_author']); ?>"
           required>
    <br><br>

    <textarea name="new_content"
              rows="4"
              required><?php echo htmlspecialchars($citationToEdit['content']); ?></textarea>
    <br><br>

    <input type="hidden" name="update_id"
           value="<?php echo $citationToEdit['id']; ?>">

    <button type="submit" class="btn btn-edit">💾 Mettre à jour</button>
</form>

<hr>
<?php endif; ?>

<!-- =========================
     NAVIGATION
========================= -->
<div style="margin-bottom:20px;">
    <a href="logout.php" class="btn btn-delete">⬅ Déconnexion</a>
</div>

<!-- =========================
     LISTE
========================= -->
<h2>Citations enregistrées</h2>

<?php
$stmt = $pdo->query(
    "SELECT id, content, citation_author, author
     FROM citations
     ORDER BY created_at DESC"
);

foreach ($stmt as $row):
?>

<div class="citation-card">

    <p>
        “<?php echo htmlspecialchars($row['content']); ?>”<br>
        <em>— <?php echo htmlspecialchars($row['citation_author']); ?></em><br>
        <small>Ajouté par <?php echo htmlspecialchars($row['author']); ?></small>
    </p>

    <?php if (
        $_SESSION['role'] === 'admin' ||
        $row['author'] === $_SESSION['user']
    ): ?>

    <div class="action-buttons">

        <form method="POST">
            <input type="hidden" name="delete_id"
                   value="<?php echo $row['id']; ?>">
            <button type="submit" class="btn btn-delete">
                🗑 Supprimer
            </button>
        </form>

        <form method="GET">
            <input type="hidden" name="edit_id"
                   value="<?php echo $row['id']; ?>">
            <button type="submit" class="btn btn-edit">
                ✏ Modifier
            </button>
        </form>

    </div>

    <?php endif; ?>

</div>

<?php endforeach; ?>

</main>

</body>
</html>
