<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CitaTime</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>


<header>
    Bienvenue !
</header>

<div class="container">

    <!-- PANNEAU GAUCHE -->
    <div class="sidebar">
        <h3>Qui sommes-nous ?</h3>
        <br>
        Nous sommes deux élèves de deuxième année de BTS CIEL au lycée Saint-Éloi.
        <br><br>
        Nos études nous ont poussés à créer ce site internet afin de réaliser un projet
        défini par notre enseignante, Madame AGOSTINELLI.
        <br><br>
        Ce site nous permet d’apprendre différents langages de programmation
        (HTML / CSS / PHP).
        <br><br>
        Vous pourrez y retrouver des citations, inscrire les vôtres et trouver de l’inspiration.
    </div>

    <!-- CONTENU CENTRAL -->
    <div class="main-content">
        <h1>Formulaire d’identification</h1>

        <form action="login.php" method="POST">

            <label>NOM :</label><br>
            <input type="text" name="username" required>
            <br><br>

            <label>MDP :</label><br>
            <input type="password" name="password" required>
            <br><br>

            <button type="submit">Connexion</button>
        </form>

        <!-- MESSAGE D’ERREUR -->
        <?php if (isset($_GET['error'])): ?>
            <p style="color:red; margin-top:15px;">
                Identifiants incorrects
            </p>
        <?php endif; ?>

    </div>

    <!-- PANNEAU DROIT -->
    <div class="sidebar-right">

        <a href="https://citatime.ct.ws/">
            <img src="../medias/Logo.png" height="200" width="200" alt="Logo Site">
        </a>

        <br><br><br><br>
        <hr style="margin:20px 0;">

<a href="visitor.php">
    <button type="button">Accéder en tant que visiteur</button>
</a>

        <br><br><br><br>

        <a href="https://lycee-saint-eloi.com/">
            <img src="../medias/Lycee.png" height="150" width="150" alt="Logo St Eloi">
        </a>

    </div>

</div>


<footer>
    JULIEN Joan // BALLAN Gabriel
</footer>

</body>
</html>
